// === Personalización rápida ===
;(function(){
  const params = new URLSearchParams(location.search)
  const nombre = params.get('para') || ''
  const firma = params.get('de') || ''
  const texto = params.get('msg') || ''
  if(nombre) document.getElementById('nombre-dest').textContent = nombre
  if(firma)  document.getElementById('firma').textContent = firma
  if(texto)  document.getElementById('mensaje').textContent = texto

  // Inserta un botón flotante para editar en vivo
  const edit = document.createElement('button')
  edit.textContent = 'Personalizar'
  Object.assign(edit.style,{position:'fixed',right:'16px',bottom:'16px',padding:'10px 14px',borderRadius:'999px',border:'1px solid #ffffff22',background:'#111827cc',color:'#fff',backdropFilter:'blur(6px)',cursor:'pointer',boxShadow:'0 10px 24px #0006',zIndex:10})
  edit.addEventListener('click',()=>{
    const n = prompt('¿Para quién es?', nombre || 'Mi sol')
    const f = prompt('¿De parte de quién?', firma || 'Yo')
    const m = prompt('Mensaje (una frase corta):', texto || 'Contigo quiero todos mis septiembres.')
    if(n) document.getElementById('nombre-dest').textContent = n
    if(f) document.getElementById('firma').textContent = f
    if(m) document.getElementById('mensaje').textContent = m
    history.replaceState({},'',`?para=${encodeURIComponent(n||'')}&de=${encodeURIComponent(f||'')}&msg=${encodeURIComponent(m||'')}`)
  })
  document.body.appendChild(edit)
})()

// === Tulipanes amarillos generativos ===
function tulipSVG(scale=1){
  const s = scale
  return `
        <svg width="120" height="180" viewBox="0 0 120 180" aria-hidden="true">
          <g transform="translate(60,160)">
            <path class="stem" d="M0 0 C 0 -20, -6 -60, 0 -100"/>
            <ellipse class="leaf" cx="-10" cy="-60" rx="14" ry="8" transform="rotate(-28)"/>
            <ellipse class="leaf" cx="12" cy="-80" rx="16" ry="9" transform="rotate(24)"/>
          </g>
          <g transform="translate(60,60)">
            <g>
              <path class="petal" d="M0 -8 C 22 -40, 40 -6, 24 10 C 14 20, 4 14, 0 4 Z"/>
              <path class="petal petal--light" d="M0 -8 C -22 -40, -40 -6, -24 10 C -14 20, -4 14, 0 4 Z"/>
              <path class="petal" d="M0 -8 C 0 -40, -2 -42, 0 -60 C 2 -42, 0 -40, 0 -8 Z"/>
              <circle class="center" r="6" cy="-2"/>
            </g>
          </g>
        </svg>`
}

const scene = document.querySelector('.scene')
const petalsLayer = document.getElementById('petals')

//Distribuye tulipanes con variación
const COUNT = 12
for(let i=0;i<COUNT;i++){
  const el = document.createElement('div')
  el.className = 'flower'
  const x = 6 + Math.random()*88
  const baseY = 86 + Math.random()*6
  const dur = (6 + Math.random()*4).toFixed(2)+'s'
  const wiggle = (Math.random()>.5?1:-1)*(6+Math.random()*10)+'px'
  el.style.left = x+'%'
  el.style.bottom = baseY+'px'
  el.style.setProperty('--dur', dur)
  el.style.setProperty('--wiggle', wiggle)
  el.innerHTML = tulipSVG()
  scene.appendChild(el)
}

// Pétalos cayendo
const PETALS = 36
for(let i=0;i<PETALS;i++){
  const p = document.createElement('span')
  p.style.left = Math.random()*100+'%'
  p.style.setProperty('--rot', (Math.random()*180).toFixed(0)+'deg')
  p.style.setProperty('--fall', (6+Math.random()*8).toFixed(2)+'s')
  p.style.opacity = (0.6 + Math.random()*0.4).toFixed(2)
  petalsLayer.appendChild(p)
}
