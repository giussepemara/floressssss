# Flores Amarillas — 21 de septiembre

Estructura solicitada: `docs`, `assets`, `index.html`, `js`, `css`.

## Cómo usar
1. Abre `index.html` en tu navegador.
2. Personaliza nombre, firma y mensaje con el botón **Personalizar** o usando parámetros en la URL:
   - `?para=María&de=Giussepe&msg=Contigo%20quiero%20todos%20mis%20septiembres`
3. Sube la carpeta a GitHub Pages o a cualquier hosting estático.

## Estructura
```
flores-amarillas/
├─ index.html
├─ css/
│  └─ styles.css
├─ js/
│  └─ app.js
├─ assets/
│  └─ favicon.svg
└─ docs/
   └─ README.md
```
